package com.cts.entity;

import java.util.Date;
import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;


@ApiModel(description = "This is the Twitter model")
public class TweetModel {
		
	@ApiModelProperty(value = "id of a tweet")
	@NotBlank
	@Id
	public int tweetId;
	
	@ApiModelProperty(value = "Tweet")
	@Size(max =144 )
	public String tweetDescription;
	
	@ApiModelProperty(value = "Login Id of a person")
	@NotBlank
	public String username;
	
	private String tweetTag;
	
	public String date;
	
	private char recordActive;
	
	private List<Reply> reply;
	

	public String getTweetDescription() {
		return tweetDescription;
	}

	public void setTweetDescription(String tweetDescription) {
		this.tweetDescription = tweetDescription;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getTweetTag() {
		return tweetTag;
	}

	public void setTweetTag(String tweetTag) {
		this.tweetTag = tweetTag;
	}

	
	
	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public int getTweetId() {
		return tweetId;
	}

	public void setTweetId(int tweetId) {
		this.tweetId = tweetId;
	}

	
	public String getusername() {
		return username;
	}
	public void setusername(String username) {
		this.username = username;
	}

	public char getRecordActive() {
		return recordActive;
	}

	public void setRecordActive(char recordActive) {
		this.recordActive = recordActive;
	}

	public List<Reply> getReply() {
		return reply;
	}

	public void setReply(List<Reply> reply) {
		this.reply = reply;
	}

	@Override
	public String toString() {
		return "TweetModel [tweetId=" + tweetId + ", tweetDescription=" + tweetDescription + ", username=" + username
				+ ", tweetTag=" + tweetTag + ", date=" + date + ", recordActive=" + recordActive + ", reply=" + reply
				+ "]";
	}

	
	
	
}
