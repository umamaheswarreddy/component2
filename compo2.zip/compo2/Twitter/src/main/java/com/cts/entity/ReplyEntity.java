package com.cts.entity;

import java.util.Date;

public class ReplyEntity {
	
	
	private String username;
    
    private Long tweetId;
    
    private String replyDesc;
    
    private String date;
    
	public ReplyEntity() {
		super();
	}

	public ReplyEntity(String username, Long tweetId, String replyDesc, String date) {
		super();
		this.username = username;
		this.tweetId = tweetId;
		this.replyDesc = replyDesc;
		this.date = date;
	}
	
	public Long getTweetId() {
		return tweetId;
	}

	public void setTweetId(Long tweetId) {
		this.tweetId = tweetId;
	}

	public String getReplyDesc() {
		return replyDesc;
	}

	public void setReplyDesc(String replyDesc) {
		this.replyDesc = replyDesc;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}
	
	

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((date == null) ? 0 : date.hashCode());
		result = prime * result + ((replyDesc == null) ? 0 : replyDesc.hashCode());
		result = prime * result + ((tweetId == null) ? 0 : tweetId.hashCode());
		result = prime * result + ((username == null) ? 0 : username.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ReplyEntity other = (ReplyEntity) obj;
		if (date == null) {
			if (other.date != null)
				return false;
		} else if (!date.equals(other.date))
			return false;
		if (replyDesc == null) {
			if (other.replyDesc != null)
				return false;
		} else if (!replyDesc.equals(other.replyDesc))
			return false;
		if (tweetId == null) {
			if (other.tweetId != null)
				return false;
		} else if (!tweetId.equals(other.tweetId))
			return false;
		if (username == null) {
			if (other.username != null)
				return false;
		} else if (!username.equals(other.username))
			return false;
		return true;
	}

	
	

	
	
}
