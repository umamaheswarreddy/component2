package com.cts.repository;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.entity.UserRegistration;

@Repository
public interface UserRepository extends MongoRepository<UserRegistration, String> {


	@Query("{username:?0}")
	UserRegistration findByusername(String username);

}
