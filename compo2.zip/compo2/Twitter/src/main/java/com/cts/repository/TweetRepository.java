package com.cts.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.cts.entity.TweetModel;

@Repository
public interface TweetRepository extends MongoRepository<TweetModel,Integer>{

	@Query("{'username':?0}")
	List<TweetModel> findTweetsByUsername(String username);

	List<TweetModel> findByRecordActive(char c);

}
