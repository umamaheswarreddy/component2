import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-like-comp',
  templateUrl: './like-comp.component.html',
  styleUrls: ['./like-comp.component.css']
})
export class LikeCompComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
