export class User {
    username!: any;
    email!: string;
    firstName!: string;
    lastName!: string;    
    password!: string;
    confirmPassword!: string;
    contactNumber!: string;
}
