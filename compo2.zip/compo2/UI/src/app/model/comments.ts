export class Comments {
    replyId!:number;
    username!:string;
    tweetId!:number;
    replyDesc!:string;
    date!:string;
}
