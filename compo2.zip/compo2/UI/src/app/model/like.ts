export class Like {
    username!:string;
    tweetId!:number;
    likeCount!:number;
    likes!:Array<number>
}
