import { Like } from './like';

describe('Like', () => {
  it('should create an instance', () => {
    expect(new Like()).toBeTruthy();
  });
});
